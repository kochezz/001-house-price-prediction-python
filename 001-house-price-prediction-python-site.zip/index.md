---
layout: home
author_profile: true
title: "House Price Prediction (Python)"
---

Welcome to the project page for **House Price Prediction using Multiple Linear Regression**.

📊 [Visit the live app](https://01-beda-house-price-prediction.streamlit.app/)  
📁 [Explore the source on GitHub](https://github.com/kochezz/001-house-price-prediction-python)
